import React from "react";
import "./SearchBar.css";
import SearchIcon from "./SearchIcon";

const SearchBar = ({ value, isList, onChange, placeholder}) => {
  return (
    <div className="searchBarContainer">
      <SearchIcon className="icon" />
      {isList ? (
        <input
          list="userDataList"
          className={`searchBar dataListAdjustments`}
          placeholder={placeholder}
        />
      ) : (
        <input
          className="searchBar"
          value={value}
          type="search"
          placeholder={placeholder}
          onChange={onChange}
        />
      )}
    </div>
  );
};

export default SearchBar;
