import React, { useState } from "react";
import "./SearchBar.css";
import NameList from "./NameList";
import { users } from "./users";
import SearchBar from "./SearchBar";

const ListSearch = () => {
  const [searchValue, setSearchValue] = useState("");

  const filteredUsers = users.filter((user) => {
    return user.name.toLowerCase().includes(searchValue.toLowerCase());
  });

  return (
    <div>
      <SearchBar
        value={searchValue}
        onChange={(e) => setSearchValue(e.target.value)}
        placeholder="Þekktir viðtakendur"
      />

      {filteredUsers && searchValue.length > 0 && (
        <NameList
          users={filteredUsers}
          selectedUser={(user) => setSearchValue("")}
        />
      )}
    </div>
  );
};

export default ListSearch;
