import React, { Component } from "react";
import "./App.css";
import DataList from "./DataList";
import ListSearch from "./ListSearch";

class App extends Component {
  render() {
    return (
      <div className="App">
        <div className="wrapper">
          <div className="description">React Hooks útfærsla</div>
          <ListSearch searchChange={this.onSearchChange} />
        </div>

        <div className="wrapper">
          <div className="description">HTML útfærsla</div>
          <DataList />
        </div>
      </div>
    );
  }
}

export default App;
