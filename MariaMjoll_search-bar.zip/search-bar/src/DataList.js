import React from "react";
import "./SearchBar";
import { users } from "./users";
import SearchBar from "./SearchBar";

const DataList = () => {
  return (
    <div>
      <SearchBar isList placeholder="Þekktir viðtakendur" />
      {
        <datalist id="userDataList">
          {users.map((user) => (
            <option key={`${user.name}_${user.email}`} value={user.name}>
              {user.email}
            </option>
          ))}
        </datalist>
      }
    </div>
  );
};

export default DataList;
