import React, { useState, useEffect, useCallback } from "react";
import "./NameList.css";

const NameList = ({ users, selectedUser }) => {
  const [activeUser, setActiveUser] = useState(0);

  const handleKeyDown = useCallback(
    (e) => {
      const size = users.length;
      if (e.key === "ArrowDown") {
        e.preventDefault();
        setActiveUser(activeUser === size - 1 ? 0 : activeUser + 1);
      } else if (e.key === "ArrowUp") {
        e.preventDefault();
        setActiveUser(activeUser === 0 ? size - 1 : activeUser - 1);
      }
    },
    [users.length, activeUser, setActiveUser]
  );

  useEffect(() => {
    document.addEventListener("keydown", handleKeyDown, false);
    return () => {
      document.removeEventListener("keydown", handleKeyDown, false);
    };
  }, [handleKeyDown]);

  return (
    <ul className="nameListContainer">
      {users.length > 0 ? (
        users.map((user, i) => {
          return (
            <li key={`${user.name}_${user.email}`}>
              <button
                className={`nameListButton ${
                  activeUser === i && "activeState"
                }`}
                onClick={() => selectedUser(user)}
                onMouseOver={() => setActiveUser(i)}
              >
                <div className="nameListName">{user.name}</div>
                <div className="nameListEmail">{user.email}</div>
              </button>
            </li>
          );
        })
      ) : (
        <li className="noResultsFound">Engar niðurstöður fundust</li>
      )}
    </ul>
  );
};

export default NameList;
