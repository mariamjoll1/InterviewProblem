To get up and running:

### `npm install`

### `npm start`
